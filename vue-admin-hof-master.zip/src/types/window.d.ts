interface Window {
  _customContextmenu: {
    x: number;
    y: number;
  };
}
