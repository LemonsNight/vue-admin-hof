import Menu from "./src/Menu.vue";

export { Menu };
