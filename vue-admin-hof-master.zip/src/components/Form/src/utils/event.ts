export function formEvents() {
  const setValue = () => {};
  return { setValue };
}
