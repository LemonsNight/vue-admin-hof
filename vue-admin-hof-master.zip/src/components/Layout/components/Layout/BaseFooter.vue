<template>
  <footer class="w-full h-20px"></footer>
</template>
