<script lang="ts" setup>
import BaseLogo from "./BaseLogo.vue";
import { Menu } from "@/components/Menu";
</script>
<template>
  <BaseLogo />
  <Menu />
</template>
