import Setting from "./Setting.js";

export { Setting };
