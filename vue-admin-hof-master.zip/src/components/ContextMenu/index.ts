import ContextMenu from "./src/ContextMenu.vue";
import VMenu from "@/components/ContextMenu/src/directives/customMenu";

export { ContextMenu, VMenu };
