export interface permissionState {
  routerList: AppRouteRecordRaw[];
  token: string | null;
  permissions: string[];
}
