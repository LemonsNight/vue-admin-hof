// 登录
export const auth = {
  login: "/base-api/sys/auth/login",
};
